#ifndef LIBSYNEXENS3_PLATFORM_WINDOWS_H
#define LIBSYNEXENS3_PLATFORM_WINDOWS_H
#include"platform/platform.h"

namespace SY3_NAMESPACE
{

	namespace platform
	{

	}

};

#endif